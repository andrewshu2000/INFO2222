# INFO2222

This is a support system for university students to find help for their academic students. The web app's main features include:

* A knowledge repository for students to share reading or learning materials
* Messaging service between students and with academic staff

## Documentation
Documentation of the project is stored in a google drive folder:
https://drive.google.com/drive/folders/1jtj8oFbM5wVjaFVDXFhFywyetu_sRDfM?usp=sharing

## Virtual Machine
Currently running react site from commit `5d6ec2888dfd2b70bedd3b96b363d86b70f19a33`

Currently running api from commit `2c743ada75e072c505a49e79dae6d28992c833ea`