const content = [
    [
        {
            img: '/python3.png',
            title: 'Python',
        },
        {
            img: '/java.png',
            title: 'Java',
        },
        {
            img: '/sql.png',
            title: 'SQL',
        },
        {
            img: './assembly.png',
            title: 'Assembly',
        },
        {
            img: '/r.png',
            title: 'R',
        },
    ],
    [
        {
            title: "Trees"
        },
        {
            title: "Array"
        },
        {
            title: "Stack"
        },
        {
            title: "Queue"
        },
        {
            title: "Heap"
        },
        {
            title: "Hashmap"
        }
    ],
    [
        {
            title: "Quicksort"
        },
        {
            title: "Dijkstra"
        }
    ]
]

const title = [
    "Programming Languages",
    "Data Structures",
    "Algorithms"
]

const python = [
    {
        link: "https://www.python.org/doc/",
        title: "Documentation",
        description: "This details the docs for python 2.x and 3.x. You can also download python from here."
    },
    {
        link: "https://www.w3schools.com/python/python_intro.asp",
        title: "Reading",
        description: "Here is a gentle introduction to python, in case the documentation scares you away."
    },
    {
        link: "https://www.guru99.com/python-interview-questions-answers.html",
        title: "Common Python Interview Questions",
        description: "Here you can brush up on your python interview skills."
    }
]

export {
    content,
    title,
    python
};