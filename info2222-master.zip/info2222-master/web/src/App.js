import React, { useState } from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
import './App.css';

import UserContext from './contexts/UserContext';
import { Home, Login, Register, Profile, Manage, Help, About } from './components';

import Resource from './components/Resource';

function App() {
  const [ user, setUser ] = useState({
    user_id: null,
    loggedIn: false,
    isAdmin: false
  });

  return (
    <UserContext.Provider value={{user, setUser}}>
      <Router>
          <Switch>
            <Route exact path="/">
              <Home/>
            </Route>
            <Route path="/login">
              {user.loggedIn ? (
                <Home/>
              ) :(
                <Login />
              )}
            </Route>
            <Route path="/register">
            {user.loggedIn ? (
                <Home/>
              ) :(
                <Register/>
              )}
            </Route>
            <Route path="/topic/python">
              <Resource />
            </Route>
            <PrivateRoute path="/profile" auth={user.loggedIn}>
                <Profile />
            </PrivateRoute>
            <PrivateRoute path="/manage" auth={user.isAdmin}>
                <Manage />
            </PrivateRoute>
            <Route path="/about">
              <About />
            </Route>
            <Route path="/help">
              <Help />
            </Route>
          </Switch>
      </Router>
    </UserContext.Provider>
  );
}

function PrivateRoute({ children, auth, ...rest }) {
  return (
    <Route
      {...rest}
      render={({ location }) =>
        auth ? (
          children
        ) : (
          <Redirect
            to={{
              pathname: "/login",
              state: { from: location }
            }}
          />
        )
      }
    />
  );
}

export default App;
