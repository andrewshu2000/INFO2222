import Home from './Home';
import Login from './Login';
import Register from './Register';
import Profile from './Profile';
import Manage from './Manage';
import About from './About';
import Help from './Help';

export {
    Home,
    Login,
    Register,
    Profile,
    Manage,
    About,
    Help
}