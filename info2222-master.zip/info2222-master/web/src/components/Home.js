import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Toolbar from "@material-ui/core/Toolbar";
import CircularProgress from '@material-ui/core/CircularProgress';

import Header from './layout/Header';
import Listing from './layout/Listing';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    overflow: 'hidden',
    backgroundColor: theme.palette.background.paper,
  },
  container: {
    paddingTop: theme.spacing(2),
    paddingLeft: theme.spacing(12),
  },
  title: {
    ...theme.typography.button,
    backgroundColor: theme.palette.background.paper,
    padding: theme.spacing(1),
  },
  loading: {
    display: 'flex',
    justifyContent: 'center'
  },
}));

export default function SingleLineGridList() {
  const classes = useStyles();
  const [ topics, setTopics ] = useState([])

  useEffect(() => {
    document.title = "Tree Learning - Main Page"
    fetch('/api/topics')
    .then(response => response.json())
    .then(data => {
      if (typeof(data.error) === 'undefined') {
        setTopics(data)
      }
    })
    .catch(function(err) {
      alert('Error fetching data', err);
    })
  }, []);

  return (
    topics.length === 0 ? (
      <div>
        <Header />
        <div className={classes.loading}>
          <CircularProgress/>
        </div>
      </div>
    ) : (
      <>
        <Header />
        <div className={classes.root}>
          <Toolbar className={classes.container}>
            <h1>Resources</h1>
          </Toolbar>
        </div>
        {topics.map((topic, index) => 
            <Listing title={topic.concept_name} tiles={topic.topics[0]} key={index}/>
          )}
        
      </>
    )
  );
}