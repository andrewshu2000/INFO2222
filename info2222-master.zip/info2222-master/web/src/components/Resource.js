import React, { useState, useEffect, useContext } from 'react';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CssBaseline from '@material-ui/core/CssBaseline';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import Link from '@material-ui/core/Link';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';


import Header from './layout/Header';
import Comment from './Comment';
import UserContext from '../contexts/UserContext';
import AddResource from './modals/AddResource';
import RemoveResource from './modals/RemoveResource';

function Copyright() {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {'Copyright © '}
      <Link color="inherit" href="https://material-ui.com/">
        Tree Learning
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

const useStyles = makeStyles((theme) => ({
  icon: {
    marginRight: theme.spacing(2),
  },
  heroContent: {
    backgroundColor: theme.palette.background.paper,
    padding: theme.spacing(8, 0, 6),
  },
  heroButtons: {
    marginTop: theme.spacing(4),
  },
  cardGrid: {
    paddingTop: theme.spacing(8),
    paddingBottom: theme.spacing(8),
  },
  card: {
    height: '100%',
    display: 'flex',
    flexDirection: 'column',
  },
  cardMedia: {
    paddingTop: '56.25%', // 16:9
  },
  cardContent: {
    flexGrow: 1,
  },
  footer: {
    backgroundColor: theme.palette.background.paper,
    padding: theme.spacing(6),
  },
  resource: {
    paddingLeft: 0,
    paddingRight:0,
    justifyContent: 'space-between'
  }
}));

export default function Resource() {
  const classes = useStyles();
  const [ resources, setResources ] = useState([]);
  const [update, setUpdate] = useState(-1)

  const { user } = useContext(UserContext);

  useEffect(() => {
    fetch('/api/resource/1')
    .then(response => response.json())
    .then(data => {
      const resourceData = data.reduce((resourcesSoFar, { type, resource_id, title, url }) => {
        if (!resourcesSoFar[type]) resourcesSoFar[type] = [];
          const resource = {
            id: resource_id,
            title: title,
            url: url
          }
          resourcesSoFar[type].push(resource)
        return resourcesSoFar;
      }, {});
      document.title = "Tree Learning - Python Resource" 
      setResources(resourceData);
    })
    .catch(function(err) {
      // alert('Error fetching data', err);
    })
  }, [update]);
  

  return (
    <React.Fragment>
      <CssBaseline />
      <Header />
      <main>
        {/* Hero unit */}
        <div className={classes.heroContent}>
          <Container maxWidth="sm">
            <Typography component="h1" variant="h2" align="center" color="textPrimary" gutterBottom>
              Python
            </Typography>
            <Typography variant="h5" align="center" color="textSecondary" paragraph>
              Python is an interpreted, high level language created by Guido van Rossum in 1991. To this day
              many INFO1110 students use this programming lanuage to do finish their assignments and hope
              that they get a HD.
            </Typography>
          </Container>
        </div>
        <Container className={classes.cardGrid} maxWidth="md">
          {/* End hero unit */}
          <Grid container spacing={4}>
            {Object.keys(resources).map((type, index) => (
              <Grid item key={index} xs={12} sm={6} md={4}>
                <Card className={classes.card}>
                  <CardContent className={classes.cardContent}>
                    <Typography gutterBottom variant="h5" component="h2">
                      {type}
                    </Typography>
                     <List component="nav" aria-label="resource listing">
                      {resources[type].map((link, index) => (
                        <ListItem className={classes.resource} key={index}>
                          <Link
                            variant="body2"
                            href={link.url}
                            key={link.id}
                            target="_blank"
                            rel="noreferrer"
                          >
                          {link.title}
                          </Link>
                          {user.loggedIn ? (
                          <RemoveResource resource_id={link.id} update={update} setUpdate={setUpdate}/>
                          ) : (
                            null
                          )}
                        </ListItem>
                      ))}
                    </List>
                  </CardContent>
                  {user.loggedIn ? (
                  <CardActions>
                    <AddResource type={type} update={update} setUpdate={setUpdate}/>
                  </CardActions>
                  ): (
                    null
                  )}
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
        {user.loggedIn ? <Comment /> : null}
      </main>
      {/* Footer */}
      <footer className={classes.footer}>
        <Copyright />
      </footer>
      {/* End footer */}
    </React.Fragment>
  );
}