import React, { useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import Checkbox from '@material-ui/core/Checkbox';

import Header from './layout/Header';
import AlterUser from './modals/AlterUser';

const columns = [
  { id: 'username', label: 'Username' },
  { id: 'is_admin', label: 'Admin' },
  { id: 'is_student', label: 'Student' },
  { id: 'is_staff', label: 'Staff' },
  { id: 'is_muted', label: 'Muted' },
  { id: 'is_banned', label: 'Banned' },
  { id: 'edit', label: 'Edit' },
];

const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
  },
  container: {
    paddingTop: theme.spacing(2),
    paddingLeft: theme.spacing(12),
    paddingRight: theme.spacing(12),
  },
  userContainer: {
    // maxHeight: 440,
  },
  header: {
    marginTop: "40px",
    fontWeight: 600
  },
}));

export default function ManageTable() {
  const classes = useStyles();
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [users, setUsers] = React.useState([]);
  const [update, setUpdate] = React.useState(1);

  useEffect(() => {
    fetch('/api/users')
      .then(response => response.json())
      .then(data => {
        setUsers(data)
      })
      .catch(function (err) {
        alert('Error fetching data', err);
      })
  }, [update])

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <div>
      <Header />
      <div className={classes.container}>
      <h1>Manage Users</h1>
      <TableContainer className={classes.userContainer}>
        <Table stickyHeader aria-label="manage user table">
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                >
                  <div>{column.label}</div>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {users.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => {

              return (
                <TableRow hover role="checkbox" tabIndex={index} key={index}>
                {columns.map((column) => {
                  const value = row[column.id];
                  if (column.id === 'username') {
                    return (
                      <TableCell key={column.id} align={column.align}>
                        <div>{value}</div>
                      </TableCell>
                    );
                  } else if (column.id === 'edit') {
                    return (
                      <TableCell key={column.id} align={column.align}>
                        <AlterUser user={row} setUpdate={setUpdate} update={update}/>
                      </TableCell>
                    );
                  } else {
                    return (
                      <TableCell key={column.id} align={column.align}>
                        <Checkbox checked={value} />
                      </TableCell>
                    );
                  }
                })}
              </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component="div"
        count={users.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onChangePage={handleChangePage}
        onChangeRowsPerPage={handleChangeRowsPerPage}
      />
      </div>
    </div>

  );
}