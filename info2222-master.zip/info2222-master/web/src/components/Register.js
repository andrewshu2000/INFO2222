import React, { useState, useCallback, useContext, useEffect } from 'react';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';

import { useHistory } from 'react-router-dom';

import UserContext from '../contexts/UserContext';
import Header from './layout/Header';

function Copyright() {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {'Copyright © '}
      <Link color="inherit" href="https://material-ui.com/">
        Tree Learning
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',

  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

export default function Register() {
  const classes = useStyles();
  const [ email, setEmail ] = useState('');
  const [ username, setUsername ] = useState('');
  const [ password, setPassword ] = useState('');
  const [ confirmPassword, setConfirmPassword ] = useState('');
  const [ emailError, setEmailError ] = useState('');
  const [ usernameError, setUsernameError ] = useState('');
  const [ passwordError, setPasswordError ] = useState('')

  const registerUser = useCallback(() => {
    const requestParams = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: email,
        username: username,
        password: password
      })
    }

    if (password != confirmPassword) {
      console.log("passwords do not match")
      return
    }

    fetch('/api/register', requestParams)
    .then(response => console.log(response))

  }, [email, username, password, confirmPassword])

  useEffect(() => {
    document.title = "Tree Learning - Register"
  }, [])
  const { setUser } = useContext(UserContext);
  const history = useHistory();

  const register_user = useCallback((e) => {
    e.preventDefault();
    setEmailError('');
    setUsernameError('');
    setPasswordError('');

    const requestOptions = {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        email: email,
        username: username,
        password: password
      })
    }

    if (email.length === 0) {
      setEmailError('Please fill in your email')
    }

    if (username.length === 0) {
      setUsernameError('Please fill in your username');
    }

    if (password.length === 0) {
      setPasswordError('Please fill in your password');
    }

    if (password !== confirmPassword) {
      setPasswordError('The two passwords do not match');
    }

    if (password.length === 0 || username.length === 0 || email.length === 0) {
      return
    }

    fetch('/api/register', requestOptions)
    .then(response => response.json())
    .then((data) => {
      if (typeof(data.error) !== 'undefined') {
          if (data.error.includes('email')) {
            setEmailError(data.error)
          } else (
            setUsernameError(data.error)
          )
          return
      }
      setUser({
        user_id: data.current_id,
        loggedIn: true,
        isAdmin: data.is_admin,
      })
      history.push('/')
    })
    .catch(() => {
      setUsernameError("An error occured. PLease try again later")
      setPasswordError("An error occured. PLease try again later")
    })
  }, [username, password, confirmPassword, email, history, setUser])

  return (
  <>
    <Header/>
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <Typography component="h1" variant="h5">
          Register
        </Typography>
        <form className={classes.form} noValidate onSubmit={register_user}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                id="email"
                label="Educational Email"
                name="email"
                autoComplete="email"
                error={emailError.length > 0}
                helperText={emailError}
                onChange={e => setEmail(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                id="username"
                label="Username"
                name="username"
                autoComplete="username"
                error={usernameError.length > 0}
                helperText={usernameError}
                onChange={e => setUsername(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                name="password"
                label="Password"
                type="password"
                id="password"
                autoComplete="current-password"
                error={passwordError.length > 0}
                helperText={passwordError}
                onChange={e => setPassword(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                name="password"
                label="Confirm password"
                type="password"
                id="confirm-password"
                autoComplete="current-password"
                error={passwordError.length > 0}
                helperText={passwordError}
                onChange={e => setConfirmPassword(e.target.value)}
              />
            </Grid>
          </Grid>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            onClick={registerUser}
          >
            Register
          </Button>
          <Grid container justify="flex-end">
            <Grid item>
              <Link href="/login" variant="body2">
                Already have an account? Login
              </Link>
            </Grid>
          </Grid>
        </form>
      </div>
      <Box mt={5}>
        <Copyright />
      </Box>
    </Container>
    </>
  );
}