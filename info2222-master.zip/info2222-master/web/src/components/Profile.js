import React, { useEffect, useState, useContext } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardMedia from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import Typography from '@material-ui/core/Typography';
import Avatar from '@material-ui/core/Avatar';
import Container from '@material-ui/core/Container';

import Header from './layout/Header';
import UserContext from '../contexts/UserContext';

const useStyles = makeStyles((theme) => ({
  card: {
    margin: '40px 100px' 
  },
  media: {
    height: 110,
  },
  avatar: {
    margin: '-60px 0 0 0',
    width: 90,
    height: 90,
    align: 'left'
  },
   title: {
    fontWeight: 600,
    marginTop: -10
  },
  subtitle: {
    fontSize: 15
  },
}));

export default function Profile() {
    const classes = useStyles();
    const [ role, setRole ] = useState('None');
    const [ status, setStatus ] = useState('None');
    const [ username, setUsername ] = useState('');
    const [ email, setEmail ] = useState('');

    const { user } = useContext(UserContext);

    useEffect(() => {
        fetch('/api/user/' + user.user_id)
        .then(response => response.json())
        .then(data => {
          if (typeof(data.error) === 'undefined') {
            const roles = []
            const status = []
            if (data.is_admin) {
                roles.push("Administrator")
            } 
            if (data.is_staff) {
                roles.push("Staff")
            } 
            if (data.is_student) {
                roles.push("Student")
           
            }
            if (data.is_muted) {
                status.push("Muted")
            }
            if (data.is_banned) {
                status.push("Banned")
            }
            setRole(roles.join(', '))
            setStatus(status.join(', '))
            setUsername(data.username)
            setEmail(data.email)
            document.title = "Tree Learning - " + data.username + "'s Profile"
          }
        })
        .catch(function(err) {
          alert('Error fetching data', err);
        })
      }, [user.user_id]);
      
    return (
        <>
          <Header />
            <Container>
                <Card square className={classes.card}>
                    <CardMedia
                    className={classes.media}
                    />
                    <CardHeader
                    avatar={<Avatar className={classes.avatar} />}
                    /> 
                    <CardContent className={classes.content}>
                        <Typography type='title' className={classes.title}>{username}</Typography>
                        <Typography type='caption' className={classes.subtitle}>{email}</Typography><br/>
                        <Typography type='body1'>Role: {role}</Typography>
                        <Typography type='body1'>Status: {status}</Typography>
                    </CardContent>
                </Card>
            </Container>
        </>
  );
}