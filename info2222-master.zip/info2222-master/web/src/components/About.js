import React from 'react';
import Header from './layout/Header';

import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    container: {
      paddingTop: theme.spacing(2),
      paddingLeft: theme.spacing(12),
      paddingRight: theme.spacing(12),
    }
}));

export default function About() {
    const classes = useStyles();
    return (
        <div>
            <Header/>
            <div className={classes.container}>
                <h1>About</h1>
                This is a support system for university students to find help for their academic students. The web app's main features include:
                <ul>
                    <li>A knowledge repository for students to share reading or learning materials</li>
                    <li>Messaging service between students and with academic staff</li>
                </ul>
                <h2>Academic Honesty</h2>
                o ensure the academic integrity of the resources provided on this site please refer to
                <a href="http://sydney.edu.au/policies/showdoc.aspx?recnum=PDOC2012/254&RendNum=0">The University of Sydney Academic Honesty in Coursework Policy</a>
                when you are unsure if the resource you upload complies with the academic honesty of the university.
            </div>
        </div>
    )
}