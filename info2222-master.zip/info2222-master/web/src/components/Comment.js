import React, { useState, useEffect, useContext } from 'react';
import CssBaseline from '@material-ui/core/CssBaseline';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import TextField from '@material-ui/core/TextField';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import ListItemText from '@material-ui/core/ListItemText';
import ListItem from '@material-ui/core/ListItem';
import Divider from '@material-ui/core/Divider';
import Avatar from '@material-ui/core/Avatar';
import LaptopIcon from '@material-ui/icons/Laptop';
import PersonIcon from '@material-ui/icons/Person';
import BookIcon from '@material-ui/icons/Book';
import FlashOnIcon from '@material-ui/icons/FlashOn';

import UserContext from '../contexts/UserContext';

const useStyles = makeStyles(theme => ({
    root: {
        width: "100%",
        backgroundColor: theme.palette.background.paper
    },
    fonts: {
        fontWeight: "bold"
    },
    inline: {
        display: "inline"
    },
    spacing: {
        marginTop: "50px"
    },
    header: {
        marginTop: "40px",
        fontWeight: 600
    },
    comment: {
        width: "100%",
        marginBottom: "40px",
    },
}));

export default function Comments() {
    const classes = useStyles();
    const [ comments, setComments ] = useState([]);
    const [ comment, setComment ] = useState('');
    const [ update, setUpdate ] = useState(1)

    const { user } = useContext(UserContext)

    const addComment = React.useCallback(() => {
        const requestOptions = {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
            user_id: user.user_id,
            topic_id: 1,
            comment: comment
            })
        }

      if (comment.length === 0) {
          return
      }
  
      fetch('/api/comment', requestOptions)
      .then(response => response.json())
      .then(data => {
          if (typeof(data.error) === 'undefined') {
              setComment('');
              setUpdate(-update)
          }
      })
      .catch(() => {
          //alert("Error adding comment")
          return
      })
  }, [comment, update, user.user_id])

    useEffect(() => {
        fetch('/api/1/comments')
            .then(response => response.json())
            .then(data => {
                setComments(data)
            })
            .catch(function (err) {
                alert('Error fetching data', err);
            })
    }, [addComment])

    const avatar = (comment) => {
        // different avatar based on their role
        if (comment.is_admin) {
            return (
                <div title="Administrator">
                    <FlashOnIcon alt={comment.username} />
                </div>
            );
        } else if (comment.is_staff) {
            return (
                <div title="Staff">
                    <BookIcon alt={comment.username} />
                </div>
            )
        } else if (comment.is_student) {
            return (
                <div title="Student">
                    <LaptopIcon alt={comment.username} />
                </div>
            )
        } else {
            return (
                <div title="User">
                    <PersonIcon alt={comment.username} />
                </div>
            )
        }
    }


    return (
        <>
            <CssBaseline>
                <Container>
                    <Typography className={classes.header} variant="h4">
                        Comments
                    </Typography>
                    <Grid container className={classes.spacing}>
                        <TextField
                            id="add-comment"
                            placeholder= {!user.isMuted ? "Add a Comment" : "You are muted and cannot comment"}
                            // To use multiline comments we should use a button to send the comment
                            // multiline
                            value={comment}
                            className={classes.comment}
                            onChange={(e) => setComment(e.target.value)}
                            disabled={user.isMuted}
                            onKeyPress={(e) => {
                                if (e.key === 'Enter') {
                                    addComment()
                                    setComment('')
                                }
                            }}
                        />
                        {/* Create a reversed copy of the comments and render that */}
                        {[...comments].reverse().map((comment, index) => (
                                <ListItem alignItems="flex-start" key={index}>
                                    <ListItemAvatar>
                                        <Avatar>
                                            {avatar(comment)}
                                        </Avatar>
                                    </ListItemAvatar>
                                    <ListItemText
                                        primary={
                                            <Typography className={classes.fonts}>
                                                {comment.user}
                                            </Typography>
                                        }
                                        secondary={
                                            <Typography
                                                component="span"
                                                variant="body2"
                                                className={classes.inline}
                                                color="textPrimary"
                                            >
                                                {comment.comment}
                                            </Typography>
                                        }
                                    />
                                <Divider />
                                </ListItem>
                        ))}
                    </Grid>
                </Container>
            </CssBaseline>

        </>
    )
}