import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import List from '@material-ui/core/List';
import ListItemText from '@material-ui/core/ListItemText';
import ListItem from '@material-ui/core/ListItem';
import IconButton from '@material-ui/core/IconButton';
import Checkbox from '@material-ui/core/Checkbox';
import EditIcon from '@material-ui/icons/Edit';

export default function AlterUser({user, update, setUpdate}) {
  const [open, setOpen] = React.useState(false);
  const [admin, setAdmin] = React.useState(user.is_admin)
  const [student, setStudent] = React.useState(user.is_student)
  const [staff, setStaff] = React.useState(user.is_staff)
  const [muted, setMuted] = React.useState(user.is_muted)
  const [banned, setBanned] = React.useState(user.is_banned)
            
  const alterUser = React.useCallback(() => {
    const requestOptions = {
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          user_id: user.user_id,
          is_admin: admin,
          is_student: student,
          is_staff: staff,
          is_muted: muted,
          is_banned: banned,
        })
      }
  
      fetch('/api/manage_user', requestOptions)
      .then((response) => {
          if (response.status === 200) {
              setUpdate(-update)
              setOpen(false)
          }
      })
      .catch(() => {
            handleClose()
      })
  }, [admin, student, staff, banned, muted, setUpdate, update, user.user_id])

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
        <IconButton
            aria-label="edit"
            onClick={handleClickOpen}
        >
            <EditIcon />
        </IconButton>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="edit-user-dialog-title"
        aria-describedby="edit-user-dialog-description"
      >
        <DialogTitle id="edit-user-dialog-title">Alter {user.username}</DialogTitle>
        <DialogContent>
          <DialogContentText id="edit-user-dialog-description">
              Alter {user.username}'s role and status
          </DialogContentText>
          <List>
              <ListItem>
                <ListItemText primary="Admin"/>
                <Checkbox checked={admin} onClick={() => setAdmin(!admin)}/>
              </ListItem>
              <ListItem>
                <ListItemText primary="Student" />
                <Checkbox checked={student} onClick={() => setStudent(!student)}/>
              </ListItem>
              <ListItem>
                <ListItemText primary="Staff" />
                <Checkbox checked={staff} onClick={() => setStaff(!staff)}/>
              </ListItem>
              <ListItem>
                <ListItemText primary="Muted" />
                <Checkbox checked={muted} onClick={() => setMuted(!muted)}/>
              </ListItem>
              <ListItem>
                <ListItemText primary="Banned" />
                <Checkbox checked={banned} onClick={() => setBanned(!banned)}/>
              </ListItem>
          </List>
        </DialogContent>
        <DialogActions>
            <Button onClick={handleClose} color="primary">
                Cancel
            </Button>
            <Button onClick={alterUser} color="primary" autoFocus>
                OK
            </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}