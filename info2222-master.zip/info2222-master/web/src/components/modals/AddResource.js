import React from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

export default function AddResource({type, update, setUpdate}) {
    const defaultText = 'Please enter a title and url for your resource';
    const [open, setOpen] = React.useState(false);
    const [addResourceText, setAddResourceText] = React.useState(defaultText);
    const [title, setTitle] = React.useState('');
    const [url, setUrl] = React.useState('')
    const [titleError, setTitleError] = React.useState('');
    const [urlError, setUrlError] = React.useState('');

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const addResource = React.useCallback(() => {
    const requestOptions = {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          type: type,
          url: url,
          title: title,
          topic_id: 1,
        })
      }

      if (url.length === 0) {
          setUrlError("Please fill in an url")
      }

      if (title.length === 0) {
          setTitleError("Please fill in a title")
      }

      if (url.length === 0 || title.length === 0) {
          return
      }
  
      fetch('/api/add_resource', requestOptions)
      .then(response => response.json())
      .then(data => {
          if (typeof(data.error) === 'undefined') {
              setAddResourceText('Resource added successfully')
              setUpdate(-update)
          } else {
              setUrlError(data.error)
          }
      })
      .catch(() => {
          setAddResourceText("Error adding resource")
      })
  }, [title, url, setUpdate, type, update])

  return (
    <div>
    <Button size="small" color="primary" onClick={handleClickOpen}>
        Add Resource
    </Button>
      <Dialog open={open} onClose={handleClose} aria-labelledby="add-resource-dialog-title">
        <DialogTitle id="add-resource-dialog-title">Add Resource</DialogTitle>
        {addResourceText === defaultText ? (
            <>
        <DialogContent>
          <DialogContentText>
            {addResourceText}
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            id="url"
            label="url"
            fullWidth
            onChange={(e) => setUrl(e.target.value)}
            error={urlError.length > 0}
            helperText={urlError}
          />
          <TextField
            autoFocus
            margin="dense"
            id="resource-title"
            label="Title"
            fullWidth
            onChange={(e) => setTitle(e.target.value)}
            error={titleError.length > 0}
            helperText={titleError}
          />
        </DialogContent>
        <DialogActions>
            <Button onClick={handleClose} color="primary">
                Cancel
            </Button>
            <Button onClick={addResource} color="primary" autoFocus>
                Add
            </Button>
        </DialogActions>
        </>
        ) : (
            <>
          <DialogContent>
          <DialogContentText>
            {addResourceText}
          </DialogContentText>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
                OK
            </Button>
          </DialogActions>
          </DialogContent>
          </>
        )}
      </Dialog>
    </div>
  );
}