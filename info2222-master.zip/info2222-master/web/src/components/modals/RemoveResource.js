import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';

export default function RemoveResource({resource_id, update, setUpdate}) {
    const defaultText = 'Are you sure you want to delete this resource permanently?'
  const [open, setOpen] = React.useState(false);
  const [dialogText, setDialogText] = React.useState(defaultText);
            
  const deleteResource = React.useCallback(() => {
    const requestOptions = {
        method: 'DELETE',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          resource_id: resource_id
        })
      }
  
      fetch('/api/delete_resource', requestOptions)
      .then((response) => {
          if (response.status === 200) {
              setDialogText('Resource deleted successfully')
              setUpdate(-update)
          }
      })
      .catch(() => {
          setDialogText("Error deleting resource")
      })
  }, [resource_id, setUpdate, update])

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setDialogText(defaultText)
  };

  return (
    <div>
        <IconButton
        aria-label="delete"
        onClick={handleClickOpen}
        >
            <DeleteIcon />
        </IconButton>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="delete-dialog-title"
        aria-describedby="delete-dialog-description"
      >
        <DialogTitle id="delete-dialog-title">Delete Resource</DialogTitle>
        <DialogContent>
          <DialogContentText id="delete-dialog-description">
              {dialogText}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
            {dialogText === defaultText ? (
                <>
            <Button onClick={handleClose} color="primary">
                No
            </Button>
            <Button onClick={deleteResource} color="primary" autoFocus>
                Yes
            </Button>
            </>
            ) : (
                <>
            <Button onClick={handleClose} color="primary">
                OK
            </Button>
            </>
            )}

        </DialogActions>
      </Dialog>
    </div>
  );
}