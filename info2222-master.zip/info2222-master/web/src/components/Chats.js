import React, { useEffect } from "react";
import { fade, makeStyles } from "@material-ui/core/styles";
import Dialog from "@material-ui/core/Dialog";
import InputBase from '@material-ui/core/InputBase';
import ListItemText from "@material-ui/core/ListItemText";
import ListItem from "@material-ui/core/ListItem";
import List from "@material-ui/core/List";
import Divider from "@material-ui/core/Divider";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import CloseIcon from "@material-ui/icons/Close";
import Slide from "@material-ui/core/Slide";
import CommentIcon from "@material-ui/icons/Comment";
import SearchIcon from '@material-ui/icons/Search';

import Messages from './Messages';

const useStyles = makeStyles(theme => ({
  appBar: {
    position: "relative"
  },
  title: {
    marginLeft: theme.spacing(2),
    flex: 1
  },
  scrollPaper: {
      alignItems: 'flex-end',
      justifyContent: 'flex-end',
      
  },
  message: {
    position: 'fixed',
    bottom: '0px',
    right: '0px',
    zIndex: 1
  },
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: fade(theme.palette.common.white, 0.25),
    },
    // marginRight: theme.spacing(2),
    marginLeft: 0,
    width: '100%',
    height: '',
    [theme.breakpoints.up('sm')]: {
      marginTop: theme.spacing(1),
      width: 'auto',
    },
  },
  searchIcon: {
    padding: theme.spacing(0, 2),
    // height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputRoot: {
    color: 'inherit',
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('md')]: {
        width: '20ch',
    },
  },
}));

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function Chats() {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [chats, setChats] = React.useState([]);
  const [chatOpened, setChatOpened] = React.useState(null);
  const [searchTerm, setSearchTerm] = React.useState('');

  // fetch user data when the the searchTerm is changed
  useEffect(() => {
    var get_chat_url = '/api/user_chats'
    if (searchTerm !== '') {
      get_chat_url = '/api/search_user/' + searchTerm
    }
    fetch(get_chat_url)
      .then(response => response.json())
      .then(data => {
        if (typeof(data.error) === 'undefined') {
          setChats(data)
        }
      })
      .catch(function(err) {
        alert('Error fetching data', err);
      })
  }, [searchTerm]);
  
  useEffect(() => {
    setSearchTerm('')
  }, [chatOpened]);

  // Open chat
  const handleClickOpen = () => {
    setOpen(true);
  };

  // Close chat
  const handleClose = () => {
    setOpen(false);
  };

  const chatContent = () => {
      return chats.map((chat, index) => (
        <div key={index}>
        <ListItem button onClick={() => setChatOpened(chat)}>
        <ListItemText primary={chat.user} />
        </ListItem>
        <Divider />
        </div>
      )
    )
  }

  return (
    <div className={classes.message}>
      <IconButton variant="outlined" color="primary" size="medium" onClick={handleClickOpen}>
        <CommentIcon fontSize="large" />
      </IconButton>
      <Dialog
        open={open}
        onClose={handleClose}
        TransitionComponent={Transition}
        BackdropProps={{
          style: {
            backgroundColor: "transparent",
            boxShadow: "none",
          }
        }}
        classes={{
            scrollPaper: classes.scrollPaper,
          }}
      >
        {chatOpened === null ? (
          <>
          <AppBar className={classes.appBar}>
            <Toolbar>
              <IconButton
                edge="start"
                color="inherit"
                onClick={handleClose}
                aria-label="close"
              >
                <CloseIcon />
              </IconButton>
              <Typography variant="h6" className={classes.title}>
                Chats
              </Typography>
            </Toolbar>
          </AppBar>
          <div className={classes.search}>
              <div className={classes.searchIcon}>
              <SearchIcon />
              </div>
              <InputBase
              key="search"
              placeholder="Search User"
              classes={{
                  root: classes.inputRoot,
                  input: classes.inputInput,
              }}
              inputProps={{ 'aria-label': 'search' }}
              onChange={(e) => {
                setSearchTerm(e.target.value)
              }}
              // onKeyPress={(e) => {
              //   setSearchTerm(e.target.value)
              //   // if (e.key === 'Enter') {
              //   //     searchUser() 
              //   // }
              // }}
              />
          </div> 
          <List>
            {chatContent()}
          </List>
          </>
        ) : (
          <Messages
            user_id={chatOpened.user_id}
            setChatOpened={setChatOpened}
            username={chatOpened.user}
          />
        )}
      </Dialog>
    </div>
  );
}
