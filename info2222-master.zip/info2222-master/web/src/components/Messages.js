import React, { useEffect, useState } from "react";
import { fade, makeStyles } from "@material-ui/core/styles";
import InputBase from '@material-ui/core/InputBase';
import ListItem from "@material-ui/core/ListItem";
import List from "@material-ui/core/List";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import SendIcon from '@material-ui/icons/Send';

const useStyles = makeStyles(theme => ({
  appBar: {
    position: "relative"
  },
  title: {
    marginLeft: theme.spacing(2),
    flex: 1
  },
  message: {
    position: 'fixed',
    bottom: '0px',
    right: '0px' 
  },
  sendMessage: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: fade(theme.palette.common.white, 0.25),
    },
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(3),
      width: 'auto',
    },
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  messageIcon: {
    padding: theme.spacing(0, 2),
    height: '100%',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  rightMessage: {
      justifyContent: 'flex-end'
  },
  leftMessage: {
      textAlign: 'flex-end'
  }
}));

export default function Messages({ user_id, username, setChatOpened }) {
    const classes = useStyles();
    const [ messages, setMessages ] = useState([])
    const [message, setMessage] = useState('')
    const [update, setUpdate] = useState(1)

    const sendMessage = React.useCallback(() => {
      const requestOptions = {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          to_id: user_id,
          message: message
        })
      }

      if (message.length === 0) {
          return
      }
  
      fetch('/api/message', requestOptions)
      .then(response => response.json())
      .then(data => {
          if (typeof(data.error) === 'undefined') {
              setMessage('');
              setUpdate(-update)
          }
      })
      .catch(() => {
          alert("Error sending message")
      })
  }, [message, update, user_id])


    useEffect(() => {
        fetch('/api/' + user_id + '/messages')
        .then(response => response.json())
        .then(data => {
          if (typeof(data.error) === 'undefined') {
            setMessages(data)
          }
        })
        .catch(function(err) {
          // alert('Error fetching data', err);
        })
    }, [update, user_id])

    return (
        <>
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={() => setChatOpened(null)}
              aria-label="close"
            >
              <ArrowBackIosIcon />
            </IconButton>
            <Typography variant="h6" className={classes.title}>
              {username}
            </Typography>
          </Toolbar>
        </AppBar>
        <List>
            {messages.map((message, index) => (
                <div key={index}>
                <ListItem className={user_id !== message.from_id ? classes.rightMessage : classes.leftMessage}>
                    <Typography variant="body1" component="h2">
                        {message.message}
                    </Typography>
                </ListItem>
                </div>
            ))}
        </List>
        <div className={classes.sendMessage}>
            <InputBase
            placeholder="Send Message"
            classes={{
                root: classes.inputRoot,
                input: classes.inputInput,
            }}
            value={message}
            inputProps={{ 'aria-label': 'send' }}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => {
                if (e.key === 'Enter') {
                    sendMessage() 
                }
              }}
            />
            <Button className={classes.messageIcon} onClick={sendMessage}>
                <SendIcon />
            </Button>
        </div> 
        </>
    )
}