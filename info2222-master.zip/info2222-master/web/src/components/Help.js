import React from 'react';
import Header from './layout/Header';

import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    container: {
      paddingTop: theme.spacing(2),
      paddingLeft: theme.spacing(12),
      paddingRight: theme.spacing(12),
    }
}));

export default function About() {
    const classes = useStyles();
    return (
        <div>
            <Header/>
            <div className={classes.container}>
                <h1>Help</h1>
                <h2>Resources</h2>
                You can see any of the resources listed on this site free of charge. Each resource is sorted by topic, and each topic contain resource links.
                Once registered, you are free to add or remove any resources that you see fit. Please do respect the hard work of others though.
                <h2>Comments</h2>
                You may comment on any topic, and see what others have commented. Hover your mouse over the user's profile to see what role they are.
                <h2>Messaging</h2>
                There is a very rudimentary messaging system where you can search for users and send them a message. Please do be polite or you might get banned by an admin.
                <h2>Academic Honesty</h2>
                While the University is aware that the vast majority of students and staff act ethically and honestly, it is opposed to and will not tolerate academic dishonesty or plagiarism and will treat all allegations of dishonesty seriously.

                To ensure the academic integrity of the resources provided on this site please refer to 
                <a href="http://sydney.edu.au/policies/showdoc.aspx?recnum=PDOC2012/254&RendNum=0">The University of Sydney Academic Honesty in Coursework Policy</a>
                when you are unsure if the resource you upload complies with the academic honesty of the university.
                
                Please ensure that:
                <ul>
                    <li>You do not put copyrighted materials such as textbooks and past papers without the author's permission</li>
                    <li>You do not post other student's work without their consent</li>
                    <li>You do not plagiarise from the resources provided</li>
                </ul>
            </div>
        </div>
    )
}