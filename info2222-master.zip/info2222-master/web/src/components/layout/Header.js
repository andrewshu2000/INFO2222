import React, { useEffect, useContext } from 'react';
import { useHistory } from 'react-router-dom';
import { useLocation } from "react-router-dom";
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Button from '@material-ui/core/Button';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

import UserContext from '../../contexts/UserContext';
import Chats from '../Chats';

const useStyles = makeStyles((theme) => ({
  appBar: {
    borderBottom: `1px solid ${theme.palette.divider}`,
    flexDirection: 'row',
  },
  logo: {
      height: 30,
      margin: theme.spacing(0, 1.5),
    },
    toolbar: {
      flexWrap: 'wrap',
    },
    toolbarTitle: {
      flexGrow: 1,
      justifyContent: 'flex-end',
    },
    link: {
      margin: theme.spacing(1, 1.5),
    },
  }));
  
export default function Header() {
  const classes = useStyles();
  const path =  useLocation().pathname;
  const [ value, setValue ] = React.useState(-1);
  const { user, setUser } = useContext(UserContext);
  const history = useHistory();

  
  useEffect(() => {
    const current = () => {
      switch(path) {
        case "/help":
          return 2;
        case "/about":
          return 1;
        case "/":
          return 0;
        default:
          return false;
      }
    }

    setValue(current())
  }, [path]);

  useEffect(() => {
    fetch('/api/logged_in')
      .then(response => response.json())
      .then(data => {
        if (typeof(data.error) === 'undefined') {
          user.loggedIn = data.logged_in
        }
      })
      .catch(function(err) {
        alert('Error fetching data', err);
      })
  },[user.loggedIn]);
  
  const handleChange = (e, newValue) => {
    setValue(newValue);
  };
  
  const loginButton = () => {
    return path !== '/login' && !user.loggedIn ? (
      <Button label="LOGIN" onClick={() => history.push('/login')} color="primary" variant="outlined" className={classes.link}>
            Login
        </Button>
    ) : null
  }
  
  const logoutButton = () => {
    return user.loggedIn ? (
      <Button label="LOGOUT" onClick={logout} color="primary" variant="outlined" className={classes.link}>
            Logout
        </Button>
    ) : null
  }


  const logout = () => {
    fetch('/api/logout')
    .then(() => {
      setUser({
        user_id: null,
        loggedIn: false,
        isAdmin: false
      })
      history.push('/')
    })
  }

  const registerButton = () => {
      return path !== '/register' && !user.loggedIn ? (
          <Button label="REGISTER" onClick={() => history.push('/register')} color="primary" variant="contained" className={classes.link}>
              Register
          </Button>
      ) : null
  }

  const profile = () => {
    return user.loggedIn ? (
      <Button label="PROFILE" onClick={() => history.push('/profile')}>
          Profile
      </Button>
    ) : null
  }

  const manage = () => {
    return user.loggedIn && user.isAdmin? (
      <Button label="MANAGE" onClick={() => history.push('/manage')}>
          Manage
      </Button>
    ) : null;
  }

  const chat = () => {
    return user.loggedIn ? (
      <Chats/>
    ) : null
  }

  return (
    <div>
    <AppBar position="static" color="default" elevation={0} className={classes.appBar}>
      <Tabs
      value={value}
      onChange={handleChange}
      variant="standard"
      indicatorColor="primary"
      textColor="primary"
      aria-label="nav tabs"
      className={classes.toolbarTitle}
    >
      <Tab label="HOME" onClick={() => history.push('/')}/>
      <Tab label="ABOUT" onClick={() => history.push('/about')}/>
      <Tab label="HELP" onClick={() => history.push('/help')}/>
    </Tabs>

    {loginButton()}
    {registerButton()}
    {profile()}
    {manage()}
    {logoutButton()}
    </AppBar>

    {chat()}
    </div>
  )
}