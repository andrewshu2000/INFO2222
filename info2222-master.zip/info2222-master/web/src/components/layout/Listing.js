import React from 'react';
import { useHistory } from 'react-router-dom';
import Link from '@material-ui/core/Link';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import GridList from '@material-ui/core/GridList';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    overflow: 'hidden',
    backgroundColor: theme.palette.background.paper,
  },
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  paper: {
    padding: theme.spacing(2),
    display: 'flex',
    overflow: 'auto',
    flexDirection: 'column',
  },
  gridList: {
    flexWrap: 'nowrap',
    // Promote the list into his own layer on Chrome. This cost memory but helps keeping high FPS.
    transform: 'translateZ(0)',
  },
  titleBar: {
    background:
      'linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)',
  },
  icon: {
    color: 'white'
  },
  divider: {
    marginBottom: theme.spacing(4),
  },
  title: {
    position: 'relative',
    padding: `${theme.spacing(2)}px ${theme.spacing(4)}px ${theme.spacing(1) + 6}px`,
    fontWeight: 500
  },
}));

export default function Listing(props) {
  const classes = useStyles();
  const tiles = props.tiles;
  const title = props.title;
  const history = useHistory();

  const get_resource = (event) => {
    event.preventDefault();
    history.push('/topic/python')
  }

  return (
    <Container maxWidth="lg" className={classes.container}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Typography component="h3" variant="h6" color="textPrimary" gutterBottom>
              {title}
            </Typography>
            <Divider className={classes.divider}/>
            <GridList className={classes.gridList} cols={4.5}>
              {tiles.map((tile, index) => (
                <Link
                  component="button"
                  variant="h5"
                  onClick={get_resource}
                  key={index}
                  className={classes.title}
                >
                  {tile.topic_name}
                </Link>
              ))}
            </GridList>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
}