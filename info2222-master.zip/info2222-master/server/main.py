# Add api folder to path
import sys
import bottle
import api
import cherrypy

app = application = bottle.default_app()
host = '127.0.0.1'
port = 8000

if __name__ == '__main__':
    cherrypy.tree.graft(app, '/')
    try:
        cherrypy.server.start()
    except KeyboardInterrupt:
        cherrypy.server.stop()


