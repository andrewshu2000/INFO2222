import configparser
import datetime
import psycopg2

import traceback
import sys

# This class is a simple handler for all of our SQL database actions
# Practicing a good separation of concerns, we should only ever call 
# These functions from our models

# If you notice anything out of place here, consider it to your advantage and don't spoil the surprise

class SQLDatabase():
    '''
        Our SQL Database
    '''
    # Get the database connection
    def __init__(self):
        # Read the config file
        config = configparser.ConfigParser()
        config.read('config.ini')
        if 'database' not in config['DATABASE']:
            config['DATABASE']['database'] = config['DATABASE']['user']

        # Create a connection to the database
        try:
            # Parses the config file and connects using the connect string
            self.conn = psycopg2.connect(database=config['DATABASE']['database'],
                                        user=config['DATABASE']['user'],
                                        password=config['DATABASE']['password'],
                                        host=config['DATABASE']['host'])
            self.conn.autocommit = True
            self.cur = self.conn.cursor()
        except psycopg2.OperationalError as operation_error:
            print("""Error, you haven't updated your config.ini or you have a bad
            connection, please try again. (Update your files first, then check
            internet connection)
            """)
            print(operation_error)
            self.conn = self.cur = None

    def execute(self, sql_string, params=None):
        out = None
        for string in sql_string.split(";"):
            try:
                self.cur.execute(string, params)
                if self.cur.description != None:
                    out = self.cur.fetchall()
            except Exception as e:
                print(e)
                traceback.print_exception(*sys.exc_info())
                pass
        return out

    # Commit changes to the database
    def commit(self):
        self.conn.commit()

    #-----------------------------------------------------------------------------
    # User handling
    #-----------------------------------------------------------------------------

    # Add a user to the database
    def add_user(self, username, password, email,  admin='false', banned='false', muted='false', staff='false', student='true'):
        sql_cmd = """
                INSERT INTO info2222.UserAccount(username, password, email, admin, banned, muted, staff, student)
                VALUES(%s, %s, %s, %s, %s, %s, %s, %s)
            """
        res = self.execute(sql_cmd, (username, password, email, admin, banned, muted, staff, student,))
        self.commit()
        
        return res
    
    # check if username already exists in database
    def username_available(self, username):
        sql_cmd = """
                SELECT COUNT(*) FROM info2222.UserAccount WHERE username=%s
        """
        res = self.execute(sql_cmd, (username,))
        if res:
            return res[0][0] == 0
    
    # check if email has been registered in the database
    def email_available(self, email):
        sql_cmd = """
                SELECT COUNT(*) FROM info2222.UserAccount WHERE email=%s
        """
        res = self.execute(sql_cmd, (email,))
        if res:
            return res[0][0] == 0
    
    # get the user id given their username
    def get_id(self, username):
        sql_cmd = """
                SELECT id FROM info2222.UserAccount WHERE username=%s
        """
        return self.execute(sql_cmd, (username,))
    
    #-----------------------------------------------------------------------------
    # Resource Handling
    #-----------------------------------------------------------------------------
    
    # get concepts
    def get_concepts(self):
        sql_cmd = """
                SELECT * FROM info2222.Concept
                ORDER BY id ASC
        """
        return self.execute(sql_cmd)
    
    # get topics for concepts
    def get_topics(self, id):
        sql_cmd = """
            SELECT id, name FROM info2222.Topic
            WHERE concept_id=%s
            ORDER BY id ASC
        """
        return self.execute(sql_cmd, (id,))

    # get resource given topic id
    def get_resource(self, topic_id):
        sql_cmd = """
            SELECT id, resource_type, resource_url, title, description
            FROM info2222.Resource
            WHERE topic_id=%s
            ORDER BY id ASC
        """
        return self.execute(sql_cmd, (topic_id,))

    # add resource to a topic
    def add_resource(self, resource_type, url, title, description, topic_id):
        sql_cmd = """
                INSERT INTO info2222.Resource(resource_type, resource_url, title, description, topic_id)
                VALUES(%s, %s, %s, %s, %s)
        """
        self.execute(sql_cmd, (resource_type, url, title, description, topic_id,))
        self.commit()

    #-----------------------------------------------------------------------------
    # Resource Handling
    #-----------------------------------------------------------------------------

    # check resource to add already exists
    def url_exists(self, url):
        sql_cmd = """
                SELECT COUNT(*) FROM info2222.Resource WHERE resource_url=%s
        """
        res = self.execute(sql_cmd, (url,))
        if res:
            return res[0][0] != 0
    
    def delete_resource(self, resource_id):
        sql_cmd = """
            DELETE FROM info2222.Resource WHERE id=%s
        """
        self.execute(sql_cmd, (resource_id,))
        self.commit()
    
    def resource_exists(self, resource_id):
        sql_cmd = """
                SELECT COUNT(*) FROM info2222.Resource WHERE id=%s
        """
        res = self.execute(sql_cmd, (resource_id,))
        if res:
            return res[0][0] != 0
    
    #-----------------------------------------------------------------------------
    # Comment and Messaging Handling
    #-----------------------------------------------------------------------------

    # Retrieve all comments on a resource
    def get_comments(self, resource_id):
        sql_cmd = """
                SELECT C.id, user_id, comment, UA.admin, UA.staff, UA.student, UA.username
                FROM info2222.Comment C
                    JOIN info2222.UserAccount UA ON (C.user_id = UA.id)
                WHERE topic_id=%s
                ORDER BY id ASC
        """
        res = self.execute(sql_cmd, (resource_id,))
        return res

    # Add comment to the database
    def add_comment(self, user_id, topic_id, comment):
        sql_cmd = """
                INSERT INTO info2222.Comment(user_id, topic_id, comment)
                VALUES(%s, %s, %s)
        """
        self.execute(sql_cmd, (user_id, topic_id, comment,))
        self.commit()

    # Get all chats for a user
    def get_chats(self, user_id):
        sql_cmd = """
                SELECT C.id, from_id, FROM_U.username, to_id, TO_U.username
                FROM info2222.Chat C
                    JOIN info2222.UserAccount FROM_U ON (C.from_id = FROM_U.id)
                    JOIN info2222.UserAccount TO_U ON (C.to_id = TO_U.id)
                WHERE from_id=%s OR to_id=%s
        """
        return self.execute(sql_cmd, (user_id, user_id,))
    
    def get_chat(self, user_id1, user_id2):
        sql_cmd = """
            SELECT id FROM info2222.Chat
            WHERE (from_id=%s AND to_id=%s)
            OR (from_id=%s AND to_id=%s)
        """
        return self.execute(sql_cmd, (user_id1, user_id2, user_id2, user_id1,))

    def create_chat(self, from_id, to_id):
        sql_cmd = """
                INSERT INTO info2222.Chat(from_id, to_id) VALUES(%s, %s)
        """
        self.execute(sql_cmd, (from_id, to_id,))
        self.commit()
    
    def add_message(self, chat_id, from_id, message, read=False):
        sql_cmd = """
                INSERT INTO info2222.Message(chat_id, from_id, message, read, time)
                VALUES(%s, %s, %s, %s, %s)
        """
        time = datetime.datetime.now()
        self.execute(sql_cmd, (chat_id, from_id, message, read, time))
        self.commit()

    def get_messages(self, chat_id):
        sql_cmd = """
                SELECT from_id, message, read, time
                FROM info2222.Message
                WHERE chat_id=%s
                ORDER BY time ASC
        """

        return self.execute(sql_cmd, (chat_id,))

    #-----------------------------------------------------------------------------

    # Check login credentials
    def check_credentials(self, username, password):
        sql_cmd = """
                SELECT id, username, admin, banned, muted
                FROM info2222.UserAccount
                WHERE username=%s AND password=%s
        """
        return self.execute(sql_cmd, (username, password, ))

    #-----------------------------------------------------------------------------
    # User Management
    #-----------------------------------------------------------------------------
    def search_users(self, username):
        sql_cmd = """
            SELECT id, username
            FROM info2222.UserAccount
            WHERE lower(username) ~ lower(%s)
            ORDER BY id ASC
        """
        return self.execute(sql_cmd, (username,))

    def all_user_details(self):
        sql_cmd = """
                SELECT id, username, admin, student, staff, muted, banned
                FROM info2222.UserAccount
                ORDER BY id ASC
        """
        return self.execute(sql_cmd)
    
    def user_profile(self, user_id):
        sql_cmd = """
                SELECT username, email, admin, student, staff, muted, banned
                FROM info2222.UserAccount
                WHERE id=%s
        """
        return self.execute(sql_cmd, (user_id,))
    
    def alter_user(self, user_id, admin, student, staff, muted, banned):
        sql_cmd = """
            UPDATE info2222.UserAccount
            SET admin=%s, student=%s, staff=%s, muted=%s, banned=%s
            WHERE id=%s
        """
        self.execute(sql_cmd, (admin, student, staff, muted, banned, user_id,))
        self.commit()
        