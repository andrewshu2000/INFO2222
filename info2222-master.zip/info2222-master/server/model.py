'''
    Our Model class
    This should control the actual "logic" of your website
    And nicely abstracts away the program logic from your page loading
    It should exist as a separate layer to any database or data structure that you might be using
    Nothing here should be stateful, if it's stateful let the database handle it
'''
import random
import sql
import json

# Initialise sql database connextion
sql_db = sql.SQLDatabase()

# Login state
logged_in = False

# User details
current_id = -1
admin = False
muted = False

#-----------------------------------------------------------------------------
# Register User
#-----------------------------------------------------------------------------

def register_user(username, password, email):
    global logged_in
    global current_id
    global admin

    if not sql_db.email_available(email):
        return ("Account with that email already exists",  {})
    if not sql_db.username_available(username):
        return ("This username has already been taken", {})
    
    logged_in = True
    sql_db.add_user(username, password, email)
    current_id = sql_db.get_id(username)
    admin = False
    user_data = {
        'current_id': current_id,
        'is_admin': False
    }
    return ("", user_data)

#-----------------------------------------------------------------------------
# Check the login credentials
#-----------------------------------------------------------------------------

def login_check(username, password):
    '''
        login_check
        Checks usernames and passwords

        :: username :: The username
        :: password :: The password

        Returns either a view for valid credentials, or a view for invalid credentials
    '''
    global logged_in
    global current_id
    global admin
    global muted

    err_msg = ''
    user_data = {}
    user = sql_db.check_credentials(username, password)
    if user:
        current_id, username, admin, banned, muted = user[0]
        if banned:
            err_msg = "Account is banned"
        else:
            user_data = {
                'is_admin': admin,
                'current_id': current_id,
                'is_muted': muted
            }
            logged_in = True
    else:
        err_msg = "Username or password is incorrect. Please try again"
    return (err_msg, user_data)

#-----------------------------------------------------------------------------

def logout():
    global logged_in
    global current_id
    global admin
    logged_in = False
    current_id = -1
    admin = False

def is_logged_in():
    global logged_in
    return {"logged_in":logged_in}

#-----------------------------------------------------------------------------
# Main Page
#-----------------------------------------------------------------------------

# main topics
def get_concepts():
    data = []
    concepts = sql_db.get_concepts()
    if concepts is not None:
        for concept in concepts:
            id, name = concept
            data.append({
                'concept_id': id,
                'concept_name': name,
                'topics': []
            })
    return data

# subtopics
def get_topics(concept_id):
    data = []
    topics = sql_db.get_topics(concept_id)
    if topics is not None:
        for topic in topics:
            id, name = topic
            data.append({
                'topic_id': id,
                'topic_name': name
            })
    return data
    
#-----------------------------------------------------------------------------
# Resources
#-----------------------------------------------------------------------------

def get_resource(id):
    data = []
    resources = sql_db.get_resource(id)
    if resources is not None:
        for resource in resources:
            resource_obj = {}
            id, resource_type, url, title, description = resource
            resource_obj['resource_id'] = id
            resource_obj['type'] = resource_type
            resource_obj['url'] = url
            resource_obj['title'] = title
            resource_obj['description'] = description
            data.append(resource_obj)
    return data
    
def add_resource(resource_type, url, title, description, topic_id):
    global logged_in
    
    if logged_in:
        if sql_db.url_exists(url):
            return "Resource being added already exists"
        sql_db.add_resource(resource_type, url, title, description, topic_id)
        return ""
    else:
        return "Need to log in to add resource"

def delete_resource(id):
    global logged_in
    
    if logged_in:
        if not sql_db.resource_exists(id):
            return "Resource attempting to delete does not exist"
        sql_db.delete_resource(id)
        return ""
    else:
        return "Need to log in to delete resource"

#-----------------------------------------------------------------------------
# Comment and Messaging
#-----------------------------------------------------------------------------

def get_comments(topic_id):
    data = []
    comments = sql_db.get_comments(topic_id)
    if comments is not None:
        for comment in comments:
            comment_obj = {}
            comment_id, user_id, text, is_admin, is_staff, is_student, user = comment
            comment_obj['comment_id'] = comment_id
            comment_obj['user_id'] = user_id
            comment_obj['comment'] = text
            comment_obj['is_admin'] = is_admin
            comment_obj['is_staff'] = is_staff
            comment_obj['is_student'] = is_student
            comment_obj['user'] = user
            data.append(comment_obj)
    return data

def add_comment(user_id, topic_id, comment):
    global logged_in
    global current_id
    global muted
    if muted:
        return "You can't comment since you're muted"
    
    if logged_in and int(user_id) == current_id:
        sql_db.add_comment(user_id, topic_id, comment)
    else:
        return "Need to be logged in to add comment"        

def get_chats(user_id):
    global logged_in
    global current_id
    data = []
    if logged_in and (int(user_id) == current_id):
        chats = sql_db.get_chats(user_id)
        if chats is not None:
            for chat in chats:
                chat_obj = {}
                chat_id, from_id, to_id = chat
                chat_obj['chat_id'] = chat_id
                chat_obj['from_id'] = from_id
                chat_obj['to_id'] = to_id
                data.append(chat_obj)
    return data

def get_user_chats():
    global logged_in
    global current_id
    data = []
    if logged_in:
        chats = sql_db.get_chats(current_id)
        if chats is not None:
            for chat in chats:
                chat_obj = {}
                chat_id, from_id, from_user, to_id, to_user = chat

                if int(to_id) == current_id:
                    chat_obj['user_id'] = from_id
                    chat_obj['user'] = from_user
                else:
                    chat_obj['user_id'] = to_id
                    chat_obj['user'] = to_user
                data.append(chat_obj)
    return data

def get_messages(to_id):
    global logged_in
    global current_id
    data = []
    if logged_in:
        chat = sql_db.get_chat(current_id, to_id)
        if chat == []:
            sql_db.create_chat(current_id, to_id)
            chat = sql_db.get_chat(current_id, to_id)
        
        chat_id = chat[0][0]
        messages = sql_db.get_messages(chat_id)
        if messages is not None:
            for message in messages:
                message_obj = {}
                from_id, message, read, time = message
                message_obj['from_id'] = from_id
                message_obj['message'] = message
                message_obj['read'] = read
                message_obj['time'] = time.isoformat()
                data.append(message_obj)
    return data

def send_message(to_id, message):
    global logged_in
    global current_id
    if logged_in:
        chat = sql_db.get_chat(current_id, to_id)
        chat_id = chat[0][0]
        sql_db.add_message(chat_id, current_id, message)

#-----------------------------------------------------------------------------
# User Management
#-----------------------------------------------------------------------------

def search_users(username):
    global logged_in
    data = []
    if logged_in:
        users = sql_db.search_users(username)
        if users is not None:
            for user in users:
                user_id, username = user
                user_obj = {
                    'user_id': user_id,
                    'user': username
                }
                data.append(user_obj)
    return data

def all_user_details():
    global logged_in
    global admin
    data = []
    if logged_in and admin:
        user_details = sql_db.all_user_details()
        if user_details is not None:
            for user in user_details:
                user_id, username, administrator, student, staff, muted, banned = user
                user_obj = {
                    'user_id': user_id,
                    'username': username,
                    'is_admin': administrator,
                    'is_student': student,
                    'is_staff': staff,
                    'is_muted': muted,
                    'is_banned': banned
                }
                data.append(user_obj)
    return data

def get_profile(user_id):
    global logged_in
    global current_id
    profile = {}
    if logged_in and int(user_id) == current_id:
        user = sql_db.user_profile(user_id)
        username, email, admin, student, staff, muted, banned = user[0]
        profile = {
            'username': username,
            'email': email,
            'is_admin': admin,
            'is_student': student,
            'is_staff': staff,
            'is_muted': muted,
            'is_banned': banned
        }
    return profile

def manage_user(user_id, is_admin, student, staff, muted, banned):
    global logged_in
    global admin
    if logged_in and admin:
        sql_db.alter_user(user_id, is_admin, student, staff, muted, banned)
    else:
        return "Insufficient privileges to alter user"
