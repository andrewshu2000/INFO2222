import subprocess
import requests
import json

host = 'http://localhost'
port = ':8000'

#reset_script = '../../db/reset_db.sh'
#subprocess.call(reset_script)

#----------------------------------------------------------
# Register testing
#----------------------------------------------------------
def test_new_user():
    endpoint = '/api/register'
    data = {
        'email': 'test.edu.au',
        'username': 'test',
        'password': 'test'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 200)

def test_email_taken():
    endpoint = '/api/register'
    data = {
        'email': 'test.edu.au',
        'username': 'newuser',
        'password': 'password'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 409)
    assert(r.json()['error'] == 'Account with that email already exists')

def test_username_taken():
    endpoint = '/api/register'
    data = {
        'email': 'diff_test.edu.au',
        'username': 'test',
        'password': 'test'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 409)
    assert(json.loads(r.text)['error'] == "This username has already been taken")

def test_edu_email():
    endpoint = '/api/register'
    data = {
        'email': 'test',
        'username': 'test',
        'password': 'test'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 400)
    assert(json.loads(r.text)['error'] == 'Not an educational email')

#----------------------------------------------------------
# Login Testing
#----------------------------------------------------------

def test_login():
    endpoint = '/api/login'
    data = {
        'username': 'admin',
        'password': 'admin'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 200)
    assert(r.json()['is_admin'] == True)

def test_banned_login():
    endpoint = '/api/login'
    data = {
        'username': 'bad_boy',
        'password': 'treelearn'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 401)
    assert(r.json()['error'] == 'Account is banned')

def test_failed_login():
    endpoint = '/api/login'
    data = {
        'username': 'tester',
        'password': 'password'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 401)
    assert(r.json()['error'] == 'Username or password is incorrect. Please try again')

#----------------------------------------------------------
# Manage Users Testing
#----------------------------------------------------------
def test_sql_injection():
    pass

if __name__ == '__main__':
    #test_new_user()
    #test_email_taken()
    #test_username_taken()
    #test_edu_email()
    #test_login()
    #test_banned_login()
    #test_failed_login()