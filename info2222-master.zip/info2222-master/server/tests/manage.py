import subprocess
import requests

host = 'http://localhost'
port = ':8080'

#reset_script = '../../db/reset_db.sh'
#subprocess.call(reset_script)

def test_search_user():
    endpoint = '/api/search_user/admin'
    r = requests.get(host + port + endpoint)
    assert(r.status_code == 200)
    assert(r.json() == [
        {
            "user_id": 1,
            "username": "admin"
        }
    ])

def test_get_users():
    endpoint = '/api/users'
    r = requests.get(host + port + endpoint)
    assert(r.status_code == 200)
    assert(r.json() == [
        {
            'user_id': 1, 
            'username': 'admin',
            'is_admin': True,
            'is_student': False,
            'is_staff': False,
            'is_muted': False,
            'is_banned': False
        },
        {
            'user_id': 2,
            'username': 'joe',
            'is_admin': False,
            'is_student': True,
            'is_staff': False,
            'is_muted': False,
            'is_banned': False
        },
        {
            'user_id': 3,
            'username': 'bad_boy',
            'is_admin': False,
            'is_student': True,
            'is_staff': False,
            'is_muted': False,
            'is_banned': True
        },
        {
            'user_id': 4,
            'username': 'loud_mouth',
            'is_admin': False,
            'is_student': True,
            'is_staff': False,
            'is_muted': True,
            'is_banned': False
        },
        {
            'user_id': 5,
            'username': 'Dr Prof',
            'is_admin': False,
            'is_student': False,
            'is_staff': True,
            'is_muted': False,
            'is_banned': False
        }
    ])

def test_get_user_info():
    endpoint = '/api/user/1'
    r = requests.get(host + port + endpoint)
    assert(r.status_code == 200)
    assert(r.json() == {
        "username": "admin",
        "email": "admin@admin.edu.au",
        "is_admin": True,
        "is_student": False,
        "is_staff": False,
        "is_muted": False,
        "is_banned": False
    })

def test_alter_user():
    endpoint = '/api/manage_user'
    data = {
        'user_id': 2,
        'is_admin': False,
        'is_student': False,
        'is_staff': False,
        'is_muted': True,
        'is_banned': True
    }
    r = requests.put(host + port + endpoint, json=data)
    assert(r.status_code == 200)
    endpoint = '/api/users'
    r = requests.get(host + port + endpoint)
    assert(r.json() == [
        {
            'user_id': 1, 
            'username': 'admin',
            'is_admin': True,
            'is_student': False,
            'is_staff': False,
            'is_muted': False,
            'is_banned': False
        },
        {
            'user_id': 2,
            'username': 'joe',
            'is_admin': False,
            'is_student': False,
            'is_staff': False,
            'is_muted': True,
            'is_banned': True
        },
        {
            'user_id': 3,
            'username': 'bad_boy',
            'is_admin': False,
            'is_student': True,
            'is_staff': False,
            'is_muted': False,
            'is_banned': True
        },
        {
            'user_id': 4,
            'username': 'loud_mouth',
            'is_admin': False,
            'is_student': True,
            'is_staff': False,
            'is_muted': True,
            'is_banned': False
        },
        {
            'user_id': 5,
            'username': 'Dr Prof',
            'is_admin': False,
            'is_student': False,
            'is_staff': True,
            'is_muted': False,
            'is_banned': False
        }
    ])

def test_alter_user_no_auth():
    endpoint = '/api/manage_user'
    data = {
        'user_id': 2,
        'is_admin': False,
        'is_student': False,
        'is_staff': False,
        'is_muted': True,
        'is_banned': True
    }
    r = requests.put(host + port + endpoint, json=data)
    assert(r.status_code == 401)
    assert(r.json() == {"error": "Insufficient privileges to alter user"})

if __name__ == '__main__':
    # login
    requests.post(host + port + '/api/login', json={
        'username': 'admin',
        'password': 'admin'
    })
    #test_search_user()
    #test_get_users()
    #test_get_user_info()
    #test_alter_user()
    # logout
    requests.get(host + port + '/api/logout')
    test_alter_user_no_auth()