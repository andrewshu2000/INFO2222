import subprocess
import requests

host = 'http://localhost'
port = ':8080'

#reset_script = '../../db/reset_db.sh'
#subprocess.call(reset_script)

def test_get_comments():
    endpoint = '/api/1/comments'
    r = requests.get(host + port + endpoint)
    assert(r.status_code == 200)
    assert(r.json() == [
        {
            "comment_id": 1,
            "user_id": 4,
            "comment": "hello"
        },
        {
            "comment_id": 2,
            "user_id": 4,
            "comment": "hello"
        },
        {
            "comment_id": 3,
            "user_id": 4,
            "comment": "hello"
        },
        {
            "comment_id": 4,
            "user_id": 4,
            "comment": "hello"
        },
        {
            "comment_id": 5,
            "user_id": 4,
            "comment": "hello"
        },
        {
            "comment_id": 6,
            "user_id": 1,
            "comment": "hi"
        },
        {
            "comment_id": 7,
            "user_id": 5,
            "comment": "hello there"
        }
    ])

def test_add_comment():
    endpoint = '/api/comment'
    data = {
        'user_id': 1,
        'topic_id': 1,
        'comment': 'test comment'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 200)

def test_get_chats():
    endpoint = '/api/1/chats'
    r = requests.get(host + port + endpoint)
    assert(r.json() == [
        {
            "chat_id": 1, 
            "from_id": 1,
            "to_id": 2
        },
        {
            "chat_id": 2,
            "from_id": 5,
            "to_id": 1
        }
    ])

def test_get_messages():
    endpoint = '/api/1/messages'
    r = requests.get(host + port + endpoint)
    assert(r.json() == [
        {
            "from_id": 2,
            "message": "hi",
            "read": False,
            "time": "2020-04-19T10:08:25"
        },
        {
            "from_id": 1,
            "message": "hi",
            "read": False,
            "time": "2020-04-19T10:10:25"
        }
    ])

def test_send_message():
    endpoint = '/api/message'
    data = {
        'from_id': 1,
        'to_id': 2,
        'message': 'test_message'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 200)

def test_send_new_message():
    endpoint = '/api/message'
    data = {
        'from_id': 1,
        'to_id': 3,
        'message': 'bad'
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 200)

if __name__ == '__main__':
    # login
    requests.post(host + port + '/api/login', json={
        'username': 'admin',
        'password': 'admin'
    })
    #test_get_comments()
    #test_add_comment()
    #test_get_chats()
    #test_get_messages()
    #test_send_message()
    #test_send_new_message()