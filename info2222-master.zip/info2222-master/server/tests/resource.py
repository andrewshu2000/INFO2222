import subprocess
import requests

host = 'http://localhost'
port = ':8080'

reset_script = '../../db/reset_db.sh'
subprocess.call(reset_script)

def test_get_topics():
    endpoint = '/api/topics'
    r = requests.get(host + port + endpoint)
    assert(r.json() == [
        {
            "concept_id": 1,
            "concept_name": "Programming Languages",
            "topics": [
                {
                    "topic_id": 1,
                    "topic_name": "Python"
                },
                {
                    "topic_id": 2,
                    "topic_name": "Java"
                },
                {
                    "topic_id": 3,
                    "topic_name": "SQL"
                },
                {
                    "topic_id": 4,
                    "topic_name": "Assembly"
                },
                {
                    "topic_id": 5,
                    "topic_name": "R"
                }
            ]
        },
        {
            "concept_id": 2,
            "concept_name": "Data Structures",
            "topics": [
                {
                    "topic_id": 6,
                    "topic_name": "Trees"
                },
                {
                    "topic_id": 7,
                    "topic_name": "Array"
                },
                {
                    "topic_id": 8,
                    "topic_name": "Stack"
                },
                {
                    "topic_id": 9,
                    "topic_name": "Queue"
                },
                {
                    "topic_id": 10,
                    "topic_name": "Heap"
                },
                {
                    "topic_id": 11,
                    "topic_name": "Hashmap"
                }
            ]
        },
        {
            "concept_id": 3,
            "concept_name": "Algorithms",
            "topics": [
                {
                    "topic_id": 12,
                    "topic_name": "Quicksort"
                },
                {
                    "topic_id": 13,
                    "topic_name": "Dijstra"
                }
                ]
            }
        ]
    )
    
def test_get_resource():
    endpoint = '/api/resource/1'
    r = requests.get(host + port + endpoint)
    assert(r.json() == [
        {
            "type": "Documentation",
            "url": "https://www.python.org/doc/",
            "title": "Python docs",
            "description": ""
        },
        {
            "type": "Reading",
            "url": "https://www.w3schools.com/python/python_intro.asp",
            "title": "Introduction to Python",
            "description": ""
        },
        {
            "type": "Questions",
            "url": "https://www.w3schools.com/python/python_intro.asp",
            "title": "Interview Questions",
            "description": ""
        }
    ])

def test_get_resource_no_exist():
    endpoint = '/api/resource/0'
    r = requests.get(host + port + endpoint)
    assert(r.status_code == 404)
    assert(r.json() == {'error': 'The requested resource does not exist'})

def test_add_resource():
    endpoint = '/api/add_resource'
    data = {
        'type': 'Reading',
        'url': 'www.testing.com',
        'title': 'test read',
        'topic_id': 1
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 200)

def test_add_resource_exist():
    endpoint = '/api/add_resource'
    data = {
        'type': 'Reading',
        'url' : 'https://www.python.org/doc/',
        'title': 'test resource',
        'topic_id': 1
    }
    r = requests.post(host + port + endpoint, json=data)
    assert(r.status_code == 409)
    assert(r.json() == {'error': 'Resource being added already exists'})

def test_delete_resource():
    endpoint = '/api/delete_resource'
    data = {
        'resource_id': 1
    }
    r = requests.delete(host + port + endpoint, json=data)
    assert(r.status_code == 200)

def test_delete_resource_no_exist():
    endpoint = '/api/delete_resource'
    data = {
        'resource_id': 0
    }
    r = requests.delete(host + port + endpoint, json=data)
    assert(r.status_code == 404)
    assert(r.json() == {'error': 'Resource attempting to delete does not exist'})

if __name__ == '__main__':
    # login
    requests.post(host + port + '/api/login', json={
        'username': 'admin',
        'password': 'admin'
    }
    #test_get_topics()
    #test_get_resource()
    #test_get_resource_no_exist()
    #test_add_resource()
    #test_add_resource_exist()
    #test_delete_resource()
    #test_delete_resource_no_exist()