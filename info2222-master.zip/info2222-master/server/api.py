'''
    REST API using Bottle
    Log: source IP, date/time, request method (POST, GET etc), payload and response code 
'''

from bottle import hook, route, get, post, delete, put, request, response, error
import json
import model

#-----------------------------------------------------------------------------
# Allow CORS
#-----------------------------------------------------------------------------

_allow_origin = '*'
_allow_methods = 'PUT, GET, POST, DELETE, OPTIONS'
_allow_headers = 'Authorization, Origin, Accept, Content-Type, X-Requested-With'

@hook('after_request')
def enable_cors():
    '''Add headers to enable CORS'''
    response.headers['Access-Control-Allow-Origin'] = _allow_origin
    response.headers['Access-Control-Allow-Methods'] = _allow_methods
    response.headers['Access-Control-Allow-Headers'] = _allow_headers

@hook('after_request')
def payload_log():
    try:
        print("request payload: ", request.json)
    except:
        pass
        

@route('/', method = 'OPTIONS')
@route('/<path:path>', method = 'OPTIONS')
def options_handler(path = None):
    return

#-----------------------------------------------------------------------------
# Authentication
#-----------------------------------------------------------------------------

# Attempt the login
@post('/api/login')
def post_login():
    '''
        post_login
        
        Handles login attempts
        Expects a form containing 'username' and 'password' fields
    '''
    try:
        try:
            data = request.json
        except:
            raise ValueError("Incorrect request format")
        if data is None:
            raise ValueError("No data supplied")

        try:
            # Handle the form processing
            username = data['username']
            password = data['password']
        except (TypeError, KeyError):
            raise ValueError("Missing fields")
        
        err, user_data = model.login_check(username, password)
        if len(err) > 0:
            response.status = 401
            response.headers['Content-Type'] = 'application/json'
            return json.dumps({"error": err})

    except ValueError as e:
        response.status = 400
        response.headers['Content-Type'] = 'application/json'
        err = str(e)
        return json.dumps({"error": err})

    # success
    response.status = 200
    response.headers['Content-Type'] = 'application/json'
    return json.dumps(user_data)

# register the user
@post('/api/register')
def post_register():
    '''
        post_register
        
        Handles register
        Expects a form containing 'username' and 'password' fields
    '''
    try:
        try:
            data = request.json
        except:
            raise ValueError("Incorrect request format")
        if data is None:
            raise ValueError("No data supplied")

        try:
            # Handle the form processing
            username = data['username']
            password = data['password']
            email = data['email']
        except (TypeError, KeyError):
            raise ValueError("Missing Fields")
        
        if not email.endswith(".edu.au"):
            raise ValueError("Not an educational email")
        # check if user is already registered, raise 409 error
        err, user_data = model.register_user(username, password, email)
        if len(err) > 0:
            response.status = 409
            response.headers['Content-Type'] = 'application/json'
            return json.dumps({"error": err})

    except ValueError as e:
        response.status = 400
        response.headers['Content-Type'] = 'application/json'
        err_msg = str(e)
        return json.dumps({"error": err_msg})

    # success
    response.status = 200
    return json.dumps(user_data)

@get('/api/logout')
def logout():
    model.logout()
    response.status = 200

@get('/api/logged_in')
def logged_in():
    response.status = 200
    return json.dumps(model.is_logged_in())


#-----------------------------------------------------------------------------
# Main Page
#-----------------------------------------------------------------------------

# CS Concepts and topics for the main page
@get('/api/topics')
def get_topics():
    concepts = model.get_concepts()
    for concept in concepts:
        concept['topics'].append(model.get_topics(concept['concept_id']))
    response.headers['Content-Type'] = 'application/json'
    if len(concepts) == 0:
        response.status = 400
        return json.dumps({'error': 'There was an error retrieving the topics'})
    response.status = 200
    return json.dumps(concepts)

#-----------------------------------------------------------------------------
# Resources
#-----------------------------------------------------------------------------

# get resource
@get('/api/resource/<id>')
def get_resource(id):
    resources = model.get_resource(id)
    response.headers['Content-Type'] = 'application/json'
    if len(resources) == 0:
        response.status = 404
        return json.dumps({'error': 'The requested resource does not exist'})
    response.status = 200
    return json.dumps(resources)

# add resource
@post('/api/add_resource')
def post_resource():
    try:
        try:
            data = request.json
        except:
            raise ValueError("Incorrect request format")
        if data is None:
            raise ValueError("No data supplied")

        try:
            # Handle the form processing
            resource_type = data['type']
            url = data['url']
            title = data['title']
            topic_id = data['topic_id']
        except (TypeError, KeyError):
            raise ValueError("Missing Fields")
        
        description = data.get('description', '')
        # check if resource already added, raise 409 error
        err = model.add_resource(resource_type, url, title, description, topic_id)
        if len(err) > 0:
            response.status = 409
            response.headers['Content-Type'] = 'application/json'
            return json.dumps({"error": err})

    except ValueError as e:
        response.status = 400
        response.headers['Content-Type'] = 'application/json'
        err_msg = str(e)
        return json.dumps({"error": err_msg})

    # success
    response.status = 200
    return json.dumps({"success": ""})

# delete resource
@delete('/api/delete_resource')
def delete_resource():
    try:
        try:
            data = request.json
        except:
            raise ValueError("Incorrect request format")
        if data is None:
            raise ValueError("No data supplied")

        try:
            # Handle the form processing
            resource_id = data['resource_id']
        except (TypeError, KeyError):
            raise ValueError("Missing Fields")
        
        # check if resource exists, otherwise raise 404 error
        err = model.delete_resource(resource_id)
        if len(err) > 0:
            response.status = 404
            response.headers['Content-Type'] = 'application/json'
            return json.dumps({"error": err})

    except ValueError as e:
        response.status = 400
        response.headers['Content-Type'] = 'application/json'
        err_msg = str(e)
        return json.dumps({"error": err_msg})

    # success
    response.status = 200

#-----------------------------------------------------------------------------
# Comments and Messages
#-----------------------------------------------------------------------------

# get comments to a resource page
@get('/api/<topic_id>/comments')
def get_comments(topic_id):
    comments = model.get_comments(topic_id)
    response.headers['Content-Type'] = 'application/json'
    response.status = 200
    return json.dumps(comments)

# add comment to a resource page
@post('/api/comment')
def post_comment():
    try:
        try:
            data = request.json
        except:
            raise ValueError("Incorrect request format")
        if data is None:
            raise ValueError("No data supplied")

        try:
            # Handle the form processing
            user_id = data['user_id']
            topic_id = data['topic_id']
            comment = data['comment']
        except (TypeError, KeyError):
            raise ValueError("Missing Fields")
        
        err = model.add_comment(user_id, topic_id, comment)
        if err is not None:
            response.status = 401
            response.headers['Content-Type'] = 'application/json'
            return json.dumps({"error": err})
    except ValueError as e:
        response.status = 400
        response.headers['Content-Type'] = 'application/json'
        err_msg = str(e)
        return json.dumps({"error": err_msg})

    # success
    response.status = 200

# get all chats for a user
@get('/api/<user_id>/chats')
def get_chats(user_id):
    chats = model.get_chats(user_id)
    response.headers['Content-Type'] = 'application/json'
    response.status = 200
    return json.dumps(chats)

# get all chats for the current user
@get('/api/user_chats')
def get_user_chats():
    chats = model.get_user_chats()
    response.headers['Content-Type'] = 'application/json'
    response.status = 200
    return json.dumps(chats)

# get messages from the current user to the to_id user
@get('/api/<to_id>/messages')
def get_messages(to_id):
    messages = model.get_messages(to_id)
    response.headers['Content-Type'] = 'application/json'
    response.status = 200
    return json.dumps(messages)

# send message
@post('/api/message')
def post_message():
    try:
        try:
            data = request.json
        except:
            raise ValueError("Incorrect request format")
        if data is None:
            raise ValueError("No data supplied")

        try:
            # Handle the form processing
            to_id = data['to_id']
            message = data['message']
        except (TypeError, KeyError):
            raise ValueError("Missing Fields")
        
        err = model.send_message(to_id, message)
        if err is not None:
            response.status = 401
            response.headers['Content-Type'] = 'application/json'
            return json.dumps({"error": err})
    except ValueError as e:
        response.status = 400
        response.headers['Content-Type'] = 'application/json'
        err_msg = str(e)
        return json.dumps({"error": err_msg})

    # success
    response.status = 200
    return json.dumps({"success": ""})

#-----------------------------------------------------------------------------
# User Management
#-----------------------------------------------------------------------------

# search for a user and get id
@get('/api/search_user/<username>')
def search_users(username):
    user = model.search_users(username)
    response.headers['Content-Type'] = 'application/json'
    response.status = 200
    return json.dumps(user)

@get('/api/users')
def get_users():
    user_details = model.all_user_details()
    response.headers['Content-Type'] = 'application/json'
    response.status = 200
    return json.dumps(user_details)

@get('/api/user/<user_id>')
def get_user(user_id):
    profile = model.get_profile(user_id)
    response.headers['Content-Type'] = 'application/json'
    response.status = 200
    return json.dumps(profile)

@put('/api/manage_user')
def put_user():
    try:
        try:
            data = request.json
        except:
            raise ValueError("Incorrect request format")
        if data is None:
            raise ValueError("No data supplied")

        try:
            # Handle the form processing
            user_id = data['user_id']
            admin = data['is_admin']
            student = data['is_student']
            staff = data['is_staff']
            muted = data['is_muted']
            banned = data['is_banned']
        except (TypeError, KeyError):
            raise ValueError("Missing Fields")
        
        err = model.manage_user(user_id, admin, student, staff, muted, banned)
        if err is not None:
            response.status = 401
            response.headers['Content-Type'] = 'application/json'
            return json.dumps({"error": err})
    except ValueError as e:
        response.status = 400
        response.headers['Content-Type'] = 'application/json'
        err_msg = str(e)
        return json.dumps({"error": err_msg})

    # success
    response.status = 200

@error(404)
def error404(error):
    return 'Nothing here, sorry'
