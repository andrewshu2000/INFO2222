## Server
This folder contains code to run the postgres sql api for the website

### Setup
Install all python dependancies in the current python environment by running:

```bash
pip3 install -r requirements.txt
```

Note: you should create a virtual environment first and then activate it.

```bash
source info2222/venv/bin/activate
```

Start, stop, restart on the virtual machine run:
```bash
systemctl start uwsgi.service
systemctl stop uwsgi.service 
systemctl restart uwsgi.service 
```

And to start the api server on your local machine:
```bash
python3 wsgi.py
```
