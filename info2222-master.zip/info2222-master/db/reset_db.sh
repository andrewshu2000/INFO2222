#!/bin/sh

dbname="rh"
username="rh"
export PGPASSWORD='info2222';
psql $dbname $username -a -f "`dirname $0`/schema.sql"
psql $dbname $username -a -f "`dirname $0`/mock_data.sql"