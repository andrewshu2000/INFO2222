DROP SCHEMA IF EXISTS info2222 cascade;
CREATE SCHEMA info2222;
SET search_path TO 'info2222';

DROP TABLE IF EXISTS UserAccount CASCADE;
DROP TABLE IF EXISTS Comment CASCADE;
DROP TABLE IF EXISTS Resource CASCADE;
DROP TABLE IF EXISTS Topic CASCADE;
DROP TABLE IF EXISTS Chat CASCADE;
DROP TABLE IF EXISTS Message CASCADE;

CREATE TABLE UserAccount (
    id SERIAL PRIMARY KEY,
    email VARCHAR(100) UNIQUE,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(100),
    admin BOOLEAN DEFAULT false,
    student BOOLEAN DEFAULT false,
    staff BOOLEAN DEFAULT false,
    banned BOOLEAN DEFAULT false,
    muted BOOLEAN DEFAULT false
);

CREATE TABLE Concept (
    id SERIAL PRIMARY KEY,
    name VARCHAR(60) NOT NULL
);

CREATE TABLE Topic (
    id SERIAL PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    concept_id INTEGER REFERENCES Concept(id)
);

CREATE TABLE Comment (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES UserAccount(id),
    topic_id INTEGER REFERENCES Topic(id),
    comment TEXT NOT NULL
);

CREATE TABLE Resource (
    id SERIAL PRIMARY KEY,
    resource_type VARCHAR(60),
    resource_url VARCHAR(250) NOT NULL,
    title VARCHAR(120),
    description VARCHAR(300),
    topic_id INTEGER REFERENCES Topic(id)
);

CREATE TABLE Chat (
    id SERIAL PRIMARY KEY,
    from_id INTEGER REFERENCES UserAccount(id),
    to_id INTEGER REFERENCES UserAccount(id)
);

CREATE TABLE Message (
    id SERIAL PRIMARY KEY,
    chat_id INTEGER REFERENCES Chat(id),
    from_id INTEGER REFERENCES UserAccount(id),
    message TEXT NOT NULL,
    read BOOLEAN,
    time TIMESTAMP
);
