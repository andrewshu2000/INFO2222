begin transaction;

set search_path to 'info2222';

/*===================INSERTING USERS====================*/
INSERT INTO UserAccount(email, username, password, admin) VALUES ('admin@admin.edu.au', 'admin', 'admin', TRUE);
INSERT INTO UserAccount(email, username, password, student) VALUES ('joe@uni.edu.au', 'joe', 'treelearn', TRUE);
INSERT INTO UserAccount(email, username, password, student, banned) VALUES ('bad_boy@uni.edu.au', 'bad_boy', 'treelearn', TRUE, TRUE);
INSERT INTO UserAccount(email, username, password, student, muted) VALUES ('loud_mouth@uni.edu.au', 'loud_mouth', 'treelearn', TRUE, TRUE);
INSERT INTO UserAccount(email, username, password, staff) VALUES ('prof@uni.edu.au', 'Dr Prof', 'treelearn', TRUE);
INSERT INTO UserAccount(email, username, password, student) VALUES ('bot_user@uni.edu.au', 'bot_user', 'KVgH55h3FzzJt8', TRUE);
INSERT INTO UserAccount(email, username, password, staff, admin) VALUES ('bot_admin@uni.edu.au', 'bot_admin', 'Nrc4UjWfP7xeTR', TRUE, TRUE);

/*===================INSERTING CONCEPTS====================*/
INSERT INTO Concept(name) VALUES ('Programming Languages');
INSERT INTO Concept(name) VALUES ('Data Structures');
INSERT INTO Concept(name) VALUES ('Algorithms');

/*===================INSERTING TOPICS====================*/
INSERT INTO Topic(name, concept_id) VALUES ('Python', 1);
INSERT INTO Topic(name, concept_id) VALUES ('Java', 1);
INSERT INTO Topic(name, concept_id) VALUES ('SQL', 1);
INSERT INTO Topic(name, concept_id) VALUES ('Assembly', 1);
INSERT INTO Topic(name, concept_id) VALUES ('R', 1);
INSERT INTO Topic(name, concept_id) VALUES ('Trees', 2);
INSERT INTO Topic(name, concept_id) VALUES ('Array', 2);
INSERT INTO Topic(name, concept_id) VALUES ('Stack', 2);
INSERT INTO Topic(name, concept_id) VALUES ('Queue', 2);
INSERT INTO Topic(name, concept_id) VALUES ('Heap', 2);
INSERT INTO Topic(name, concept_id) VALUES ('Hashmap', 2);
INSERT INTO Topic(name, concept_id) VALUES ('Quicksort', 3);
INSERT INTO Topic(name, concept_id) VALUES ('Dijstra', 3);

/*===================INSERTING COMMENTS====================*/
INSERT INTO Comment(user_id, topic_id, comment) VALUES (4, 1, 'hello');
INSERT INTO Comment(user_id, topic_id, comment) VALUES (4, 1, 'hello');
INSERT INTO Comment(user_id, topic_id, comment) VALUES (4, 1, 'hello');
INSERT INTO Comment(user_id, topic_id, comment) VALUES (4, 1, 'hello');
INSERT INTO Comment(user_id, topic_id, comment) VALUES (4, 1, 'hello');
INSERT INTO Comment(user_id, topic_id, comment) VALUES (1, 1, 'hi');
INSERT INTO Comment(user_id, topic_id, comment) VALUES (5, 1, 'hello there');

/*===================INSERTING CHATS====================*/
INSERT INTO Chat(from_id, to_id) VALUES (1, 2);
INSERT INTO Chat(from_id, to_id) VALUES (5, 1);

/*===================INSERTING MESSAGES====================*/
INSERT INTO Message(chat_id, from_id, message, read, time) VALUES (1, 1, 'hi', FALSE, '2020-4-19 10:10:25-07');
INSERT INTO Message(chat_id, from_id, message, read, time) VALUES (2, 5, 'hi', FALSE, '2020-4-19 10:10:25-07');
INSERT INTO Message(chat_id, from_id, message, read, time) VALUES (1, 2, 'hi', FALSE, '2020-4-19 10:08:25-07');

/*===================INSERTING RESOURCES====================*/
INSERT INTO Resource(resource_type, resource_url, title, description, topic_id) VALUES ('Documentation', 'https://www.python.org/doc/', 'Python docs', '', 1);
INSERT INTO Resource(resource_type, resource_url, title, description, topic_id) VALUES ('Reading', 'https://www.w3schools.com/python/python_intro.asp', 'Introduction to Python', '', 1);
INSERT INTO Resource(resource_type, resource_url, title, description, topic_id) VALUES ('Questions', 'https://www.guru99.com/python-interview-questions-answers.html', 'Interview Questions', '', 1);

commit;
