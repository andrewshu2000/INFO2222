## Setup files for uwsgi and nginx
- `nginx.conf` and `uwsgi_params` should be placed in `/etc/nginx/`
- `uwsgi.service` should be placed in `/etc/systemd/system/`
